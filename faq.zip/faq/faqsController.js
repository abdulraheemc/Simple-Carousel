(function () {
    "use strict";

    angular.module('app')
    .controller('FaqsController', ['$scope',
        function ($scope) {
            $scope.accordianData = [  
                                { "heading" : "About Us",         "content" : "dfh jdgh hsdghsdgdsuy sug sduykgyjssdfysdyg sdyfsdyfsfgsdyjsdy gysdg ysdgsdgsdfujhsdgfgsd sdg DS dfgsdf" },
                                { "heading" : "Terms of Use",     "content" : "dfh jdgh hsdghsdgdsuy sug sduykgyjssdfysdyg sdyfsdyfsfgsdyjsdy gysdg ysdgsdgsdfujhsdgfgsd sdg DS dfgsdf" },
                                { "heading" : "Privacy Policy",   "content" : "dfh jdgh hsdghsdgdsuy sug sduykgyjssdfysdyg sdyfsdyfsfgsdyjsdy gysdg ysdgsdgsdfujhsdgfgsd sdg DS dfgsdf" },
                                { "heading" : "Help",             "content" : "dfh jdgh hsdghsdgdsuy sug sduykgyjssdfysdyg sdyfsdyfsfgsdyjsdy gysdg ysdgsdgsdfujhsdgfgsd sdg DS dfgsdf" },
                             ];

      // To expand or collapse the current view
      //This functionality automatically closes the other expanded lists
      $scope.toggleView = function(ary, data, index){
        for(var i=0; i<ary.length; i++){
          if(i!=index) { ary[i].expanded=false; }
          else { data.expanded=!data.expanded; }
        }
      }
            $scope.faqsList = [];
        }]);
})();