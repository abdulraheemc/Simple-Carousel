(function () {
    "use strict";

    angular.module('app')
    .controller('LoginController', ['$scope',
        function ($scope) {
            $scope.text = 'LoginController';
        }]);
})();