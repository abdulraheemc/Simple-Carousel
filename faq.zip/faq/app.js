/**
* You must include the dependency on 'ngMaterial' 
*/
angular.module('app', ['ui.router','ngMaterial'])
	.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
	$urlRouterProvider.otherwise('/faqs');
	$stateProvider
		.state("home", {
			url: '/home',
			templateUrl: 'home.html',
			controller: 'HomeController',
			controllerAs: 'home',
			data: {
				pageTitle: 'Home'
			}
		})
		.state("login", {
			url: '/login', 
			templateUrl: 'login.html',
			controller: 'LoginController',
			data: {
				pageTitle: 'Login'
			}
		})
		.state("faqs", {
			url: '/faqs',
			templateUrl: 'faqs.html',
			controller: 'FaqsController',
			data: {
				pageTitle: 'FAQs'
			}
		});
	}]);