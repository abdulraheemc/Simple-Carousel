function hideLoading(){document.getElementById("loading_mask").style.width="0%"}
var ngApp=angular.module("myApp",["ngRoute","ui.bootstrap","ngAnimate","ngCookies"]);
ngApp.config(["$routeProvider",function(t){
	t.when("/",{
		controller:"MainController",
		templateUrl:"ng-templates/main.html",
		resolve:{tredingSubreddits:["$http","AJAXService",function(t,e){return e.getTredingSubReddits()}]}})
	.when("/path1/",{
		controller:"Path1Controller",
		templateUrl:"ng-templates/path1.html",
		resolve:{tredingSubreddits:["$http","AJAXService",function(t,e){return e.getTredingSubReddits()}]}})
	.when("/path2/",{
		controller:"Path2Controller",
		templateUrl:"ng-templates/path2.html"})
	.when("/faqs/",{
		controller:"FaqsController",
		templateUrl:"ng-templates/faqs.html"}).otherwise({redirectTo:"/"})}]),
ngApp.controller("LoadingController",["$scope",function(t){t.$on("$viewContentLoaded",function(){hideLoading()})}]),ngApp.factory("Utils",["$scope","$timeout","$location",function(t,e,n){var o={};return o.showLoading=function(){document.getElementById("loading_mask").style.width="100%"},o.removeLoading=function(){document.getElementById("loading_mask").style.width="0%"},o}]),angular.element(document).ready(function(){angular.bootstrap(document,["myApp"])}),ngApp.factory("AJAXService",["$http",function(t){var e={},n=function(t){return{success:!1,status:t}};return e.getTredingSubReddits=function(){return t({method:"GET",url:"https://www.reddit.com/r/trending_subreddits.json"}).then(function(t){return console.warn(t),{success:!0,data:t.data}},function(t){return console.warn(t),n(t.status)})},e}]),ngApp.directive("backgroundImage",function(){return function(t,e,n){var o=n.backImg;e.css({background:"url("+o+") no-repeat"})}}),
ngApp.controller("MainController",["$scope","tredingSubreddits",function(t,e){console.log(e),t.fillerText="",t.fillerTextMore="",e.success&&(t.fillerText=e.data.kind,t.fillerTextMore=e.data.data.children[0].data.title)}]),
ngApp.controller("FaqsController",["$scope","$timeout",function(t,a){
	t.accordianData = [
    { "id": 1,
        "imageIcon": "fa-user-circle-o",
        "heading" : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "content" : " Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS." },
      { "id": 2,
        "imageIcon": "fa-chain-broken",
        "heading" : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "content" : " Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS." },
      { "id": 3,
        "imageIcon": "fa-unlock-alt",
        "heading" : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "content" : " Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS." },
      { "id": 4,
        "imageIcon": "fa-unlock-alt",
        "heading" : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "content" : " Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS." },
      { "id": 5,
        "imageIcon": "fa-chain-broken",
        "heading" : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "content" : " Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS." },
      { "id": 6,
        "imageIcon": "fa-unlock-alt",
        "heading" : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "content" : " Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS." }
    ];
    a(function(){
	    /*angular.forEach(angular.element(".collapse.in"), function(value, key) {
	    	console.log(value, key);
	    });*/
	    console.log(angular.element(document));
		angular.forEach(angular.element(".collapse.in"), function(value, key){
			console.log(value, key);
		});
      /*angular.element(".collapse.in").each(function(){
        angular.element(this).siblings(".panel-heading").addClass('heading');
        angular.element(this).siblings(".panel-heading").find(".fa").addClass("fa-minus").removeClass("fa-plus");
      });*/
    }, 100);
    t.colorChanger = function(){
      // Toggle plus minus icon on show hide of collapse element
      /*angular.element(".collapse").on('show.bs.collapse', function(){
        angular.element(this).siblings(".panel-heading").addClass('heading');
        angular.element(this).parent().find(".fa").removeClass("fa-plus").addClass("fa-minus");
      }).on('hide.bs.collapse', function(){
        angular.element(this).siblings(".panel-heading").removeClass('heading');
        angular.element(this).parent().find(".fa").removeClass("fa-minus").addClass("fa-plus");
      });*/
    };
}]),
ngApp.controller("Path1Controller",["$scope","tredingSubreddits",function(t,e){}]),ngApp.controller("Path2Controller",["$scope",function(t){}]);