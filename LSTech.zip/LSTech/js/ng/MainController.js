ngApp.controller('MainController', function($scope, tredingSubreddits) {
	console.log(tredingSubreddits);
	$scope.fillerText="";
	$scope.fillerTextMore="";
	if(tredingSubreddits.success) {
		$scope.fillerText=tredingSubreddits.data.kind
		$scope.fillerTextMore=tredingSubreddits.data.data.children[0].data.title
	}
});