ngApp.controller('NewQuizController', ['$scope',
  function ($scope) {
  	$scope.items = [{
  		"name": "Dynamic Survey",
  		"desc": "klzdghdgjg dfghdfhg dfjgjdzjgdfgdfh dfhghj",
  		"icon": "fa fa-question-circle",
  	},{
  		"name": "Traitional Survey",
  		"desc": "klzdghdgjg dfghdfhg dfjgjdzjgdfgdfh dfhghj",
  		"icon": "fa fa-question-circle",
  	},{
  		"name": "Dynamic Survey",
  		"desc": "klzdghdgjg dfghdfhg dfjgjdzjgdfgdfh dfhghj",
  		"icon": "fa fa-question-circle",
  	},{
  		"name": "Traitional Survey",
  		"desc": "klzdghdgjg dfghdfhg dfjgjdzjgdfgdfh dfhghj",
  		"icon": "fa fa-question-circle",
  	}];
  }
]);