var ngApp = angular.module('myApp', ['ngRoute','ui.bootstrap', 'ngAnimate', 'ngCookies']);


//router
ngApp.config(function ($routeProvider) {
    $routeProvider

        .when('/',
        {
            controller: 'MainController',
            templateUrl: 'ng-templates/main.html',
              resolve: {
                tredingSubreddits: function ($http, AJAXService) {
                    //this returns promise
                  return AJAXService.getTredingSubReddits();
                }
              }

        })

        .when('/path1/',
        {
            controller: 'Path1Controller',
            templateUrl: 'ng-templates/path1.html',
              resolve: {
                tredingSubreddits: function ($http, AJAXService) {
                    //this returns promise
                  return AJAXService.getTredingSubReddits();
                }
              }

        })

        .when('/path2/',
        {
            controller: 'Path2Controller',
            templateUrl: 'ng-templates/path2.html'

        })

        .when('/faqs/',
        {
            controller: 'FaqsController',
            templateUrl: 'ng-templates/faqs.html'

        })

        // if non of the above routes
        // are matched we are setting router
        // to redirect to the RootController
        .otherwise({ redirectTo: '/'});
});


function hideLoading() {
    document.getElementById("loading_mask").style.width = "0%";
}


ngApp.controller('LoadingController', function($scope) {
    //highlight right tab
    $scope.$on('$viewContentLoaded', function() {
        hideLoading();
    });
});


ngApp.factory('Utils',function($scope, $timeout, $location){

    var UtilService = {};
    UtilService.showLoading = function() {
        document.getElementById("loading_mask").style.width = "100%";
    }
    UtilService.removeLoading = function() {
        document.getElementById("loading_mask").style.width = "0%";
    }
    return UtilService;
});


//init when document ready
angular.element(document).ready(function() {
    angular.bootstrap(document, ['myApp']);
});
