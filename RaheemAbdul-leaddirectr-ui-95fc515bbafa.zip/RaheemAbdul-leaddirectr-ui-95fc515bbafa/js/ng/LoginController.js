ngApp.controller('LoginController', ['$scope',
  function ($scope) {

  }
]);