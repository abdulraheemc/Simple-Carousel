ngApp.controller('pollFtQuizController', ['$scope','$location',
  function ($scope, $location) {
	 $scope.radTypeStatus = "Yes/No";
	 //console.log($scope.UploadPollFile);
	 
	/*Add Input S*/
	$scope.items = [{
		"id": 1,
		"option": ''
	},{
		"id": 2,
		"option": ''
	}];
	$scope.newitem = 1;

	$scope.add = function(newitem){
		$scope.items.push({"id":$scope.items.length+1,"option":''})
	}

	$scope.del = function(i){
	    $scope.items.splice(i,1);
		console.log($scope.items);
		console.log($scope.newitem);
	}
	  /*Add Input E*/


	$scope.nextStep = function(){
		$location.path( "/pollSdQuiz" );
	};

	
  }
]);