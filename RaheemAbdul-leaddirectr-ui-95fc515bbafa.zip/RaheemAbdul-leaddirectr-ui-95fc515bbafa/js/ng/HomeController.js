ngApp.controller('HomeController', function($scope) {
	console.log('Home');
	$scope.mobileMenuDisVar="";
	$scope.mobileMenuDis = function(sel){
			if(sel == "xsMobileMenu"){ 
				$scope.mobileMenuDisVar="";
			} else{				
				$scope.mobileMenuDisVar="xsMobileMenu";
			}
	}
	
});