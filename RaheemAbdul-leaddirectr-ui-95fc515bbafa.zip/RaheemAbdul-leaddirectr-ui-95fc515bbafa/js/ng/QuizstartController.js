ngApp.controller('QuizstartController', function($scope) {
	console.log('QuizstartController');
	
});