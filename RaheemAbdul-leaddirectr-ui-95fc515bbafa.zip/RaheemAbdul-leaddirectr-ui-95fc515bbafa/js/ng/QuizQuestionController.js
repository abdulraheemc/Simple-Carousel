ngApp.controller('QuizquestionController', function($scope, $timeout) {
	//console.log('QuizquestionController');
	$scope.questionCount=1;
	$scope.questionList=[{
		"questionId": 1,
		"questionName": 'Question1,Occurs when an expression is missing tokens at the end of the expression.For example.',
		"options": {
			"option1": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			},
			"option2": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			},
			"option3": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			},
			"option4": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			}
		},
	  	"questionStatus": true
	  },{
		"questionId": 2,
		"questionName": 'Question1,Occurs when an expression is missing tokens at the end of the expression.For example.',
		"options": {
			"option1": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			},
			"option2": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			},
			"option3": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			},
			"option4": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			}
		},
	  	"questionStatus": false
	  }, {
		"questionId": 3,
		"questionName": 'Question1,Occurs when an expression is missing tokens at the end of the expression.For example.',
		"options": {
			"option1": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			},
			"option2": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			},
			"option3": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			},
			"option4": {
				"optionName": 'Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',"optionStatus": false,
			}
		},
	  	"questionStatus": false
	}];
	$scope.selectedFlag = true;
	$scope.selectAnswer=function(qid, option){
	  	qid = qid - 1;
	  	for(var i = 1 ; i <= Object.keys($scope.questionList[qid]['options']).length; i++){
	  		if($scope.questionList[qid]['options']['option'+i].optionStatus == true){
	  			$scope.selectedFlag = false;
	  		}
		}
	    if($scope.selectedFlag && $scope.questionList[qid]['options'][option].optionStatus != true){
	      $scope.questionList[qid]['options'][option].optionStatus = true;
	    }
		if($scope.questionList.length > $scope.questionCount){
			$timeout(function(){
		  		$scope.questionList[qid]['questionStatus'] = false;
		  		$scope.questionList[qid+1]['questionStatus'] = true;
		  	}, 500);
		  	$scope.questionCount++;
		} 
	}
	
});