ngApp.controller('QAPageQuizController', ['$scope','$location',
  function ($scope, $location) {
    $scope.chooseFormat = [{"FormatName":"Radio","icon":"fa-dot-circle-o"},{"FormatName":"Check Box","icon":"fa-check-square-o"}];
  	$scope.formFN = {formatChangedValue :$scope.chooseFormat[0].FormatName};
  	$scope.nextStep = function(){
		  $location.path( "/thankuQuiz" );
  	};

	/*Add Input S*/
	$scope.items = [{
		"id": 1,
		"option": ''
	},{
		"id": 2,
		"option": ''
	}];
	$scope.newitem = 1;

	$scope.add = function(newitem){
		$scope.items.push({"id":$scope.items.length+1,"option":''})
	}

	$scope.del = function(i){
	    $scope.items.splice(i,1);
		console.log($scope.items);
		console.log($scope.newitem);
	}
	  /*Add Input E*/
	  	
  }
]);