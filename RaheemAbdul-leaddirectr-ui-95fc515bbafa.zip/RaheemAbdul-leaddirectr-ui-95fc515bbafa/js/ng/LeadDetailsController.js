ngApp.controller('LeadDetailsController', ['$scope',
  function ($scope) {
	  
	  $scope.dashboardLeftMenu="";
	  $scope.mobileMenuDisDash=function(){
		  if($scope.dashboardLeftMenu){
		  $scope.dashboardLeftMenu="";		  
		  } else {		  
		  $scope.dashboardLeftMenu="dashboardLeftMenu";	
		  }
	  }
	  
    $scope.leadDetailsData = [{
      "record_id": 1,
      "questionName": '1Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',
      "favourite":[{'CR':'Red','CV':'16','outlink':'www.helth.com'},{'CR':'Blue','CV':'20','outlink':'www.helth.com'},{'CR':'Yellow','CV':'8','outlink':''},{'CR':'Green','CV':'4','outlink':''}]
    },{
      "record_id": 2,
      "questionName": '2Lorem Ipsum, Proin gravida nibh vel velit auctor aliquet',
       "favourite":[{'CR':'Red','CV':'16','outlink':'www.helth.com'},{'CR':'Blue','CV':'20','outlink':'www.helth.com'},{'CR':'Yellow','CV':'8','outlink':''},{'CR':'Green','CV':'4','outlink':''}]
    }];
	 $scope.leadDetailsUser = [{'name':'kumar','email':'kumar@gmail.com','phone':'8899778993','time':'9:30pm'},{'name':'kumar','email':'kumar@gmail.com','phone':'8899778993','time':'9:30pm'},{'name':'kumar','email':'kumar@gmail.com','phone':'8899778993','time':'9:30pm'}];
  
  }
]);