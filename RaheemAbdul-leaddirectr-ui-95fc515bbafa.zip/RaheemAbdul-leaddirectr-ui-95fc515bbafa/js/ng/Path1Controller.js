ngApp.controller('Path1Controller', function($scope, tredingSubreddits) {


});