ngApp.controller('NewQuizController', ['$scope','$location',
  function ($scope, $location) {
  	$scope.items = [{
  		"name": "Dynamic Survey",
  		"desc": "klzdghdgjg dfghdfhg dfjgjdzjgdfgdfh dfhghj",
  		"icon": "fa fa-question-circle",
  	},{
  		"name": "Traitional Survey",
  		"desc": "klzdghdgjg dfghdfhg dfjgjdzjgdfgdfh dfhghj",
  		"icon": "fa fa-question-circle",
  	},{
  		"name": "Poll",
  		"desc": "klzdghdgjg dfghdfhg dfjgjdzjgdfgdfh dfhghj",
  		"icon": "fa fa-list",
  	},{
      "name": "Quiz",
      "desc": "klzdghdgjg dfghdfhg dfjgjdzjgdfgdfh dfhghj",
      "icon": "fa fa-question-circle",
    },{
      "name": "Rating",
      "desc": "klzdghdgjg dfghdfhg dfjgjdzjgdfgdfh dfhghj",
      "icon": "fa fa-question-circle",
    },{
      "name": "TBD",
      "desc": "klzdghdgjg dfghdfhg dfjgjdzjgdfgdfh dfhghj",
      "icon": "fa fa-clock-o",
    }];

    $scope.nextStep = function(){
      $location.path( "/templateQuiz" );
    } 

  }
]);