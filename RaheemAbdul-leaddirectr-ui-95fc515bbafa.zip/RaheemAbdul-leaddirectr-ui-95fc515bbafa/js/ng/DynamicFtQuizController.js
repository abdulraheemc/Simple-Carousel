ngApp.controller('dynamicFtQuizController', ['$scope','$location',
  function ($scope, $location) {

  	$scope.listOutcomeText = [{"OutcomeId":1,"OutcomeName":"Outcome No1"},{"outcomeId":2,"OutcomeName":"Outcome No2"}];
	$scope.formDy = {selectedOutcomeText :$scope.listOutcomeText[0].OutcomeName};

	/*Add Qusetion S*/
	$scope.newQuestionsListDy=[];
	$scope.questionAdd = function(newQues){
		if(newQues){
		$scope.newQuestionsListDy.push({"id":$scope.newQuestionsListDy.length+1,"QuestionList":newQues})
		$scope.addQuestionsListDy="";
		}
	}
	$scope.QuestionListDelete=function(DeleteQues){
	    $scope.newQuestionsListDy.splice(DeleteQues,1);		
	}
	/*Add Qusetion E*/
	$scope.nextStep = function(){
		$location.path( "/dynamicSdQuiz" );
	};

	
  }
]);