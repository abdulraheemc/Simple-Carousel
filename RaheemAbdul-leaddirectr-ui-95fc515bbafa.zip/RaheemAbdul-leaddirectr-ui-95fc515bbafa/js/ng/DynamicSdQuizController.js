ngApp.controller('dynamicSdQuizController', ['$scope','$location',
  function ($scope, $location) {

	$scope.listQuestionText = [{"QuestionId":1,"QuestionName":"Question No1"},{"QuestionId":2,"QuestionName":"Question No2"}];
	$scope.formDy = {selectedQuestionText :$scope.listQuestionText[0].QuestionName};

	/*Add Qusetion S*/
	$scope.newQuestionsListDy=[];
	$scope.questionAdd = function(newQues){
		if(newQues){
		$scope.newQuestionsListDy.push({"id":$scope.newQuestionsListDy.length+1,"QuestionList":newQues})
		$scope.addQuestionsListDy="";
		}
	}
	$scope.QuestionListDelete=function(DeleteQues){
	    $scope.newQuestionsListDy.splice(DeleteQues,1);		
	}
	/*Add Qusetion E*/
	
	$scope.nextStep = function(){
		$location.path( "/dynamicFlQuiz" );
	};
	
	/*Add Input S*/
	$scope.items = [{
		"id": 1,
		"option": ''
	},{
		"id": 2,
		"option": ''
	}];
	$scope.newitem = 1;

	$scope.add = function(newitem){
		$scope.items.push({"id":$scope.items.length+1,"option":''})
	}

	$scope.del = function(i){
	    $scope.items.splice(i,1);
		console.log($scope.items);
		console.log($scope.newitem);
	}
	  /*Add Input E*/
	  	
  }
]);