ngApp.controller('dynamicFlQuizController', ['$scope','$location',
  function ($scope, $location) {

  $scope.listOutcomeText = [{"OutcomeId":1,"OutcomeName":"Outcome 1"},{"outcomeId":2,"OutcomeName":"Outcome 2"}];
	$scope.formDyO = {selectedOutcomeText :$scope.listOutcomeText[0].OutcomeName};

	$scope.listQuestionText = [{"QuestionId":1,"QuestionName":"Question 1"},{"QuestionId":2,"QuestionName":"Question 2"}];
	$scope.formDyQ = {selectedQuestionText :$scope.listQuestionText[0].QuestionName};


	  	
  }
]);