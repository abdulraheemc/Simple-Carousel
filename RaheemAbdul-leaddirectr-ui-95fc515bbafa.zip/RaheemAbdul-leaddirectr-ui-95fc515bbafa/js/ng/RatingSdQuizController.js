ngApp.controller('ratingSdQuizController', ['$scope','$location',
  function ($scope, $location) {

  	
	

	
  }
]);