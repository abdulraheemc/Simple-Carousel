ngApp.controller('Path2Controller', function($scope) {

});