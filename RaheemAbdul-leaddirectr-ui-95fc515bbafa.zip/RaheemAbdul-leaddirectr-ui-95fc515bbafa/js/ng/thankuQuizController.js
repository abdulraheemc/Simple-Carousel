ngApp.controller('thankuQuizController', ['$scope','$location',
  function ($scope, $location) {
  	$scope.nextStep = function() {
  		$location.path("/finalQuiz");	
  	};
  }
]);