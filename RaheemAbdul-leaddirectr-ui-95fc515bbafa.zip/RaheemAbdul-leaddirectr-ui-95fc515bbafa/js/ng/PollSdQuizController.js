ngApp.controller('pollSdQuizController', ['$scope','$location',
  function ($scope, $location) {

  	
	

	
  }
]);