ngApp.controller('finalQuizController', ['$scope','$location',
  function ($scope, $location) {
  	$scope.copyText = function(){
  		var field = document.getElementById('shortLink');
  		field.focus();
    	field.setSelectionRange(0, field.value.length);
	  	var x = document.execCommand("copy");
	  }
  }
]);
